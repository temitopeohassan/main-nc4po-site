var CandidatesList = React.createClass({
    render: function() {
      return (
  
        <section className="browse-cat bg-theme-primary section-padding">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left title">
                  <h3 className="text-light-black header-title">Our Candidates List </h3>
                  <span className="fs-16 align-self-center"><a href="#">See All</a></span>
                </div>
              </div>
              <div className="col-12">
                <div className="category-slider swiper-container">
                  <div className="swiper-wrapper">
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category1.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Martha, NY</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category2.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Michle, CA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category3.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Adem, LA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category4.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Jimmy, CA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category5.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Nico, FL</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category6.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Richa, NY</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category7.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Jordan, NY</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category8.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Hemlet, NJ</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category9.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Ricky, LA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category8.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Casendra, LA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category9.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Rob, CA</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category8.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Mily, TX</span>
                      </a>
                    </div>
                    <div className="swiper-slide">
                      <a href="story-grid.html" className="categories">
                        <div className="icon text-custom-white bg-light-green ">
                          <img src="assets/img/categories/category9.png" className="rounded-circle" alt="categories" />
                        </div> <span className="text-light-black cat-name">Rob, NY</span>
                      </a>
                    </div>
                  </div>
                  {/* Add Arrows */}
                  <div className="swiper-button-next" />
                  <div className="swiper-button-prev" />
                </div>
              </div>
            </div>
          </div>
        </section>
      );
    }
  });