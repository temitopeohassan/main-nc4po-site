

var Slider = React.createClass({
    render: function() {
      return (
  
        <section className="about-us-slider swiper-container p-relative slider-banner-1">
          <div className="swiper-wrapper">
            <div className="swiper-slide slide-item">
              <img src="assets/img/banner/banner1.jpg" className="img-fluid full-width" alt="Banner" />
              <div className="transform-center z-index-3">
                <div className="container-fluid custom-container">
                  <div className="row justify-content-center">
                    <div className="col-lg-12 align-self-center">
                      <div className="right-side-content far-right">
                        <h5 className="text-white">Around the world.</h5>
                        <h1 className="text-white fw-600">We help all <span className="text-custom-pink">people</span> in need</h1>
                        <p className="text-white fw-400">Gray eel-catfish longnose whiptail catfish smalleye squaretail queen danio unicorn fish
                          shortnose greeneye fusilier fish silver carp nibbler sharksucker tench lookdown catfish</p>
                        <a href="#" className="btn-solid with-line btn-big mt-20 mr-1"><span>Explore <i className="fas fa-caret-right" /></span></a>
                        <a href="#" className="border-butn mt-20 ml-1"><span>Shop Now</span></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="overlay overlay-bg-dark overlay-bg-img" />
            </div>
            <div className="swiper-slide slide-item">
              <img src="assets/img/banner/banner2.jpg" className="img-fluid full-width" alt="Banner" />
              <div className="transform-center z-index-3">
                <div className="container">
                  <div className="row justify-content-center">
                    <div className="col-lg-12 align-self-center">
                      <div className="right-side-content text-center">
                        <h5 className="text-white">Around the world.</h5>
                        <h1 className="text-white fw-600">Our Helping <span className="text-custom-pink">people</span> in need</h1>
                        <p className="text-white fw-400">Gray eel-catfish longnose whiptail catfish smalleye squaretail queen danio unicorn fish
                          shortnose greeneye fusilier fish silver carp nibbler sharksucker tench lookdown catfishf</p>
                        <a href="#" className="btn-solid with-line btn-big mt-20 mr-1"><span>Shop Now <i className="fas fa-caret-right" /></span></a>
                        <a href="#" className="border-butn mt-20 ml-1"><span>Learn More</span></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="overlay overlay-bg-dark overlay-bg-img" />
            </div>
            <div className="swiper-slide slide-item">
              <img src="assets/img/banner/banner3.jpg" className="img-fluid full-width" alt="Banner" />
              <div className="transform-center z-index-3">
                <div className="container-fluid custom-container">
                  <div className="row justify-content-center">
                    <div className="col-lg-12 align-self-center">
                      <div className="left-side-content">
                        <h5 className="text-white">Around the world.</h5>
                        <h1 className="text-white fw-600">Our Helping <span className="text-custom-pink">people</span> in need</h1>
                        <p className="text-white fw-400">Gray eel-catfish longnose whiptail catfish smalleye squaretail queen danio unicorn fish
                          shortnose greeneye fusilier fish silver carp nibbler sharksucker tench lookdown catfishf</p>
                        <a href="#" className="btn-solid with-line btn-big mt-20 mr-1"><span>Learn More <i className="fas fa-caret-right" /></span></a>
                        <a href="#" className="border-butn mt-20 ml-1"><span>Shop Now</span></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="overlay overlay-bg-dark overlay-bg-img" />
            </div>
          </div>
          {/* Add Arrows */}
          <div className="swiper-button-next" />
          <div className="swiper-button-prev" />
        </section>
      );
    }
  });