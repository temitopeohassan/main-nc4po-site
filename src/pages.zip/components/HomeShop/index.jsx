var HomeShop = React.createClass({
  render: function() {
    return (
      <div>
        <section className="recent-order section-padding">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left title">
                  <h3 className="text-light-black header-title">Help Us Fund Our Campaign</h3>
                  <span className="fs-16"><a href="order-details.html">See All Bestseller</a></span>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product1.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label new"> <span>Veg</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Fancy Wallet</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$63.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product2.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label new">
                        <span>Veg</span>
                      </div>
                      <div className="product-label discount">
                        <span>25%</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Streamlined Pen</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$87.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product3.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label nonveg">
                        <span>Meat</span>
                      </div>
                      <div className="product-label discount">
                        <span>25%</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Luxurious Envelope</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$24.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product4.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label new"> <span>Veg</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Office Stamp</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$67.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product2.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label nonveg"> <span>Meat</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Streamlined Pen</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$45.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-4 col-md-6 col-sm-6">
                <div className="product-box mb-md-20">
                  <div className="product-img">
                    <a href="shop-details.html">
                      <img src="assets/img/shop/product4.jpg" className="img-fluid full-width" alt="product-img" />
                    </a>
                    <div className="product-badge">
                      <div className="product-label new"> <span>Veg</span>
                      </div>
                    </div>
                    <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                      <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                    </div>
                    <div className="cart-hover">
                      <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                    </div>
                  </div>
                  <div className="product-caption text-center">
                    <div className="product-status">
                      <ul className="product-raised">
                        <li><strong>Sold:</strong> 45,000</li>
                        <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                      </ul>
                      <div className="progress">
                        <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                      </div>
                    </div>
                    <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Streamlined Pen</a></h6>
                    <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$34.00</span>
                      <span className="text-price">$250.00</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* sell section end */}
        <section className="masonary-gallery-sec">
          <div className="container-fluid no-padding">
            <div className="row magnific-gallery">
              <div className="col-lg-6">
                <div className="full-height masonary-box p-relative">
                  <div className="masonary-text transform-center">
                    <div className="masonary-text-wrapper">
                      <div className="icon-box">
                        <img src="assets/img/gallery/thisisimage6.jpg" className="image-fit" alt="img" />
                      </div>
                      <div className="text-box">
                        <h3 className="text-custom-white">
                          Stay up-todate, Follow us on our Instagram &amp; Twitter page for daily updates
                        </h3>
                        <a href="#" className="text-custom-white fs-14"><i className="fab fa-instagram mr-2" /> @Political</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6">
                <div className="video-box full-height">
                  <div className="video_wrapper video_wrapper_full js-videoWrapper">
                    <video src="../../../../../https@www.youtube.com/watch@v=bu_zYkgu6GU" controls="controls">                                                                                                      
                      <div className="videoPoster js-videoPoster">
                        <img src="assets/img/gallery/thisisimage1.jpg" className="image-fit" alt="#" />
                        <div className="video-inner video-btn-wrapper"> <a href="JavaScript:Void(0);"><i className="pe-7s-play" /></a></div>
                      </div>
                    </video></div>
                </div>
              </div>
              <div className="row pt-0">
                <div className="col-lg-2 col-md-4 col-sm-6">
                  <div className="masonary-item p-relative">
                    <a href="assets/img/gallery/thisisimage2.jpg" className="popup">
                      <img src="assets/img/gallery/thisisimage2.jpg" className="image-fit" alt="img" />
                    </a>
                  </div>
                </div>
                <div className="col-lg-4 col-md-8 col-sm-6">
                  <div className="masonary-item p-relative">
                    <a href="assets/img/gallery/thisisimage4.jpg" className="popup">
                      <img src="assets/img/gallery/thisisimage4.jpg" className="image-fit" alt="img" />
                    </a>
                  </div>
                </div>
                <div className="col-lg-2 col-md-4 col-sm-6">
                  <div className="masonary-item p-relative">
                    <a href="assets/img/gallery/thisisimage3.jpg" className="popup">
                      <img src="assets/img/gallery/thisisimage3.jpg" className="image-fit" alt="img" />
                    </a>
                  </div>
                </div>
                <div className="col-lg-4 col-md-8 col-sm-6">
                  <div className="masonary-item p-relative">
                    <a href="assets/img/gallery/thisisimage5.jpg" className="popup">
                      <img src="assets/img/gallery/thisisimage5.jpg" className="image-fit" alt="img" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Hot Deals */}
        <section className="ex-collection section-padding bg-theme-primary">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left">
                  <h3 className="text-light-black header-title title"> Our Promise To The Community</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-xl-4 col-lg-6">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-1.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-primary text-color-secondary">Provide a better enviroment</span>
                    <h5><a href="#">More than One Life Changed</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-2.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-secondary text-color-primary">Education</span>
                    <h5><a href="#">Help for Children of the East</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-lg-12">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-3.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-primary text-color-secondary">Food &amp; Meals</span>
                    <h5><a href="#">More than One Life Changed</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-8 sm-block">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-4.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-secondary text-color-primary">Provide better enviroment</span>
                    <h5><a href="#">Help for Children of the East</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-4">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-5.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-primary text-color-secondary">Health &amp; Care</span>
                    <h5><a href="#">More than One Life Changed</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-6">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-2.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-secondary text-color-primary">Finance</span>
                    <h5><a href="#">Help for Children of the East</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-6">
                <div className="story-wrapper">
                  <img src="assets/img/story-big/about-1.jpg" alt className="full-width img-fluid mx-auto d-block" />
                  <div className="story-box-content story-content-wrapper">
                    <span className="story-badge bg-custom-primary text-color-secondary">Education</span>
                    <h5><a href="#">More than One Life Changed</a> </h5>
                    <a href="shop-details.html" className="btn btn-text btn-text-white">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*Hot deals End*/}
        {/*shopping section*/}
        <section className="section-padding our-product">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left">
                  <h3 className="text-light-black header-title title">Our Best Sellers</h3>
                </div>
              </div>
              <div className="col-xl-3 col-lg-4 col-md-4">
                <div className="large-product-box  p-relative">
                  <div className="featured-product-box box-shadow">
                    <div className="featured-pro-title">
                      <h4 className="fs-22"><strong className="text-color-primary"> Vote</strong> now don't postpone</h4>
                    </div>
                    <div className="featured-pro-content">
                      <div className="featured-pro-text">
                        <h5><a href="#">Vote for a better community.</a></h5>
                        <p>Lorem ipsum dolor sit amet, ctetur adipiscing elit, sed do eiusmod</p>
                        <p className="price">$244</p>
                      </div>
                    </div>
                    <div className="featured-pro-img">
                      <img src="assets/img/shop/featured.jpg" alt="pro-img" className="img-fluid mx-auto d-block" />
                    </div>
                    <div className="featured-pro-timer">
                      <div className="countdown-box">
                        <div className="counter-box"> <span id="cb-days" />
                        </div>
                        <div className="counter-box"> <span id="cb-hours" />
                        </div>
                        <div className="counter-box"> <span id="cb-minutes" />
                        </div>
                        <div className="counter-box"> <span id="cb-seconds" />
                        </div>
                      </div>
                    </div>
                    <div className="featured-pro-bottom">
                      <ul>
                        <li>Votes: <strong>150,000 </strong></li>
                        <li>Goal: <strong>200,000</strong> </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-9 col-lg-8 col-md-8">
                <div className="row">
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product5.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label high"> <span>Antique</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Luxury Pen</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$96.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product6.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label uni"> <span>Paintings</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Map Pin </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$40.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product7.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label Handmade"> <span>Handmade</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Metal Artwork</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$92.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product8.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label high"> <span>Antique</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Voting Pin </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$15.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product9.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label kids"> <span>Handicrafts</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Luxury Pen</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$20.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product10.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label Ceramicart"> <span>Ceramicart</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Map Pin</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$50.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product11.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label uni"> <span>Paintings</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Seal </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$23.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product5.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label kids"> <span>Handicrafts</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Intricate Calendar</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$56.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*shopping section end*/}
        {/* advertisement banner*/}
        <section className="section-padding advertisement-banner-1 center-bg-effect">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-lg-12">
                <div className="advertisement-text-1 center-block-div">
                  <h6 className="sub-head">Our Causes</h6>
                  <h3 className="text-white heading">Lets Change The World <span className="text-white">With Humanity</span></h3>
                  <div className="ad-count justify-content-center">
                    <div className="countdown-box">
                      <div className="time-box"> <span id="mb-days" />
                      </div>
                      <div className="time-box"> <span id="mb-hours" />
                      </div>
                      <div className="time-box"> <span id="mb-minutes" />
                      </div>
                      <div className="time-box"> <span id="mb-seconds" />
                      </div>
                    </div>
                  </div>
                  <a href="shop-details.html" className="btn btn-text btn-text-white mt-20">Become A Volunteer</a>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* advertisement banner*/}
        {/*Special offer*/}
        <section className="section-padding ex-collection bg-theme-primary">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left">
                  <h3 className="text-light-black header-title title">Our Donation Campaigns</h3>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6 col-md-6">
                <div className="sa-causes-single sa-causes-single-2">
                  <div className="causes-details-wrap">
                    <div className="causes-details">
                      <h5><a href="#">Help our Veterans come back</a></h5>
                      <p>Many desktop publishing package and the web page editor now use lorem Ipsum the model text lorem.</p>
                      <div className="entry-thumb mtmb-spacing">
                        <img src="assets/img/donation/article1.jpg" alt="img" className="img-fluid full-width" />
                        <div className="dontaion-category"><a href="#">Education</a></div>
                      </div>
                      <div className="cause-progress">
                        <div className="progress-bar" role="progressbar" aria-valuenow={17} aria-valuemin={0} aria-valuemax={100} style={{"width":"17%"}}>
                          <span>17%</span>
                        </div>
                      </div>
                      <div className="causes-amount">
                        <div className="left">
                          <p>Raised</p>
                          <span>$4585.00</span>
                        </div>
                        <div className="right">
                          <p>Goal</p>
                          <span>$4585.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn-area text-center">
                    <a className="btn-donation text-btn" href="#">donate now</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6 col-md-6">
                <div className="sa-causes-single sa-causes-single-2">
                  <div className="causes-details-wrap">
                    <div className="causes-details">
                      <h5><a href="#">Maintain the Congress goverment</a></h5>
                      <p>Many desktop publishing package and the web page editor now use lorem Ipsum the model text lorem.</p>
                      <div className="entry-thumb mtmb-spacing">
                        <img src="assets/img/donation/article3.jpg" alt="img" className="img-fluid full-width" />
                        <div className="dontaion-category"><a href="#">Health</a></div>
                      </div>
                      <div className="cause-progress">
                        <div className="progress-bar" role="progressbar" aria-valuenow={17} aria-valuemin={0} aria-valuemax={100} style={{"width":"17%"}}>
                          <span>17%</span>
                        </div>
                      </div>
                      <div className="causes-amount">
                        <div className="left">
                          <p>Raised</p>
                          <span>$4585.00</span>
                        </div>
                        <div className="right">
                          <p>Goal</p>
                          <span>$4585.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn-area text-center">
                    <a className="btn-donation text-btn" href="#">donate now</a>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-lg-6 col-md-6">
                <div className="sa-causes-single sa-causes-single-2">
                  <div className="causes-details-wrap">
                    <div className="causes-details">
                      <h5><a href="#">Provide a better enviroment</a></h5>
                      <p>Many desktop publishing package and the web page editor now use lorem Ipsum the model text lorem.</p>
                      <div className="entry-thumb mtmb-spacing">
                        <img src="assets/img/donation/article2.jpg" alt="img" className="img-fluid full-width" />
                        <div className="dontaion-category"><a href="#">Hygine</a></div>
                      </div>
                      <div className="cause-progress">
                        <div className="progress-bar" role="progressbar" aria-valuenow={17} aria-valuemin={0} aria-valuemax={100} style={{"width":"17%"}}>
                          <span>17%</span>
                        </div>
                      </div>
                      <div className="causes-amount">
                        <div className="left">
                          <p>Raised</p>
                          <span>$4585.00</span>
                        </div>
                        <div className="right">
                          <p>Goal</p>
                          <span>$4585.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn-area text-center">
                    <a className="btn-donation text-btn" href="#">donate now</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*shopping section*/}
        <section className="section-padding our-product">
          <div className="container-fluid custom-container">
            <div className="row">
              <div className="col-12">
                <div className="section-header-left">
                  <h3 className="text-light-black header-title title"> Help us fund our campaigns</h3>
                </div>
              </div>
              <div className="col-xl-9 col-lg-8 col-md-8">
                <div className="row">
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product12.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label high"> <span>Antique</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Luxury Pen</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$55.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product13.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label uni"> <span>Paintings</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Map Pin </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$43.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product14.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label Handmade"> <span>Handmade</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Metal Artwork</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$76.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product15.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label high"> <span>Antique</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Voting Pin </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$54.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product16.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label kids"> <span>Handicrafts</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Luxury Pen</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$32.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product17.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label Ceramicart"> <span>Ceramicart</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Map Pin</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$87.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product18.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label uni"> <span>Paintings</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">USA Seal </a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$56.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div className="product-box mb-md-20">
                      <div className="product-img">
                        <a href="shop-details.html">
                          <img src="assets/img/shop/product19.jpg" className="img-fluid full-width" alt="product-img" />
                        </a>
                        <div className="product-badge">
                          <div className="product-label kids"> <span>Handicrafts</span>
                          </div>
                        </div>
                        <div className="button-group"> <a href="wishlist.html" data-toggle="tooltip" data-placement="left" title data-original-title="Add to wishlist" tabIndex={-1}><i className="pe-7s-like" /></a>
                          <a href="#" data-toggle="modal" data-target="#quick_view"><span data-toggle="tooltip" data-placement="left" title data-original-title="Quick View"><i className="pe-7s-search" /></span></a>
                        </div>
                        <div className="cart-hover">
                          <a href="shop-details.html" className="btn-cart  fw-600" tabIndex={-1}>Add To Cart</a>
                        </div>
                      </div>
                      <div className="product-caption text-center">
                        <div className="product-status">
                          <ul className="product-raised">
                            <li><strong>Sold:</strong> 45,000</li>
                            <li><strong>Goal:</strong><span className="text-highlight"> 70,000</span></li>
                          </ul>
                          <div className="progress">
                            <div className="progress-bar progress-bar-color" style={{"width":"75%"}} />
                          </div>
                        </div>
                        <h6 className="product-title fw-500 mt-10"><a href="shop-details.html" className="text-color-secondary">Intricate Calendar</a></h6>
                        <div className="product-money mt-10"> <span className="text-color-primary fw-600 fs-16">$32.00</span>
                          <span className="text-price">$250.00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-lg-4 col-md-4">
                <div className="verticle-newsletter bg-custom-white main-box">
                  <div className="verticle-newsletter-inner">
                    <h6 className="text-light-black">Subscribe To Newsletter</h6>
                    <p className="text-light-white mb-xl-20">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <div className="group-form mb-xl-20">
                      <div className="input-group">
                        <input type="email" name="#" className="form-control form-control-submit" />
                        <div className="input-group-append">
                          <button>Subscribe</button>
                        </div>
                      </div>
                    </div>
                    <div className="register-info-box text-center">
                      <div className="icon-sec">
                        <i className="pe-7s-id" />
                      </div>
                      <h6><a href="#" className="text-light-black">Register to Vote</a></h6>
                      <p className="text-light-white mb-0">Lorem Ipsum is simply dummy text.</p>
                    </div>
                  </div>
                  <div className="verticle-newsletter-img">
                    <img src="assets/img/register.jpg" className="image-fit" alt="img" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
});